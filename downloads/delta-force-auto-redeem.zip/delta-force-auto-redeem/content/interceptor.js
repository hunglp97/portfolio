// Delta Force Auto Redeem - Main World Network Interceptor
// Chạy trong môi trường Main World để bắt trọn 100% phản hồi từ API Garena

(function () {
  if (window.__dfInterceptorInstalled) return;
  window.__dfInterceptorInstalled = true;

  // 1. Hook XMLHttpRequest (Axios của Garena sử dụng XHR)
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._reqUrl = typeof url === 'string' ? url : (url ? url.toString() : '');
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (body) {
    if (this._reqUrl && this._reqUrl.includes('RedeemCDKey')) {
      this.addEventListener('load', function () {
        try {
          const res = JSON.parse(this.responseText);
          window.dispatchEvent(
            new CustomEvent('DF_API_REDEEM_RESULT', { detail: res })
          );
        } catch (e) {}
      });
    }
    return origSend.call(this, body);
  };

  // 2. Hook console.log làm kênh dự phòng phụ (Vite app in ra console.log(g))
  const origLog = console.log;
  console.log = function (...args) {
    try {
      const obj = args[0];
      if (obj && typeof obj === 'object' && ('code' in obj) && ('msg' in obj)) {
        window.dispatchEvent(
          new CustomEvent('DF_API_REDEEM_RESULT', { detail: obj })
        );
      }
    } catch (e) {}
    origLog.apply(console, args);
  };

  // 3. Hook fetch làm kênh dự phòng thứ 3
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const url = args[0] ? (typeof args[0] === 'string' ? args[0] : args[0].url) : '';
    const res = await origFetch.apply(this, args);
    if (url && typeof url === 'string' && url.includes('RedeemCDKey')) {
      try {
        const clone = res.clone();
        clone.json().then((json) => {
          window.dispatchEvent(
            new CustomEvent('DF_API_REDEEM_RESULT', { detail: json })
          );
        }).catch(() => {});
      } catch (e) {}
    }
    return res;
  };
})();
