// Delta Force Auto Redeem - Content Script
// Built for Garena Delta Force Redemption & hlpdata.com Server Sync

(function () {
  if (window.__dfAutoRedeemInjected) return;
  window.__dfAutoRedeemInjected = true;

  const DEFAULT_SERVER_URL = "https://hlpdata.com/api/df-codes.json";
  const STORAGE_KEYS = {
    CODES: "df_codes_list",
    REDEEMED: "df_redeemed_history",
    SERVER_URL: "df_server_url",
    LAST_SYNC: "df_last_sync_time"
  };

  let allCodes = [];
  let redeemedSet = new Set();
  let serverUrl = DEFAULT_SERVER_URL;
  let isRunning = false;
  let isPaused = false;
  let stopRequested = false;

  // Stats
  let totalToRun = 0;
  let currentIdx = 0;
  let successCount = 0;
  let skipCount = 0;
  let runResults = [];

  // -------------------------------------------------------------
  // 1. Storage & Code Sync Logic
  // -------------------------------------------------------------
  async function loadInitialData() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        [STORAGE_KEYS.CODES, STORAGE_KEYS.REDEEMED, STORAGE_KEYS.SERVER_URL, STORAGE_KEYS.LAST_SYNC],
        async (data) => {
          if (data[STORAGE_KEYS.SERVER_URL]) {
            serverUrl = data[STORAGE_KEYS.SERVER_URL];
          }
          if (data[STORAGE_KEYS.REDEEMED] && Array.isArray(data[STORAGE_KEYS.REDEEMED])) {
            redeemedSet = new Set(data[STORAGE_KEYS.REDEEMED]);
          }

          // Load local bundle codes first as fallback base
          let baseCodes = [];
          try {
            const localRes = await fetch(chrome.runtime.getURL("data/default_codes.json"));
            const localData = await localRes.json();
            baseCodes = localData.codes || [];
          } catch (e) {
            console.warn("[DF-Auto] Could not load local bundle codes:", e);
          }

          // If we had cached codes from previous sync, merge them
          let cachedCodes = data[STORAGE_KEYS.CODES] || [];
          const merged = Array.from(new Set([...baseCodes, ...cachedCodes]));
          allCodes = merged;

          resolve();
        }
      );
    });
  }

  async function syncWithServer() {
    updateSyncBanner("Đang kiểm tra code mới từ " + serverUrl + "...", "loading");
    let fetchedCodes = [];

    try {
      const resp = await fetch(serverUrl, { cache: "no-cache", mode: "cors" });
      if (resp.ok) {
        const json = await resp.json();
        fetchedCodes = Array.isArray(json) ? json : (json.codes || []);
        console.log("[DF-Auto] Successfully fetched from server:", fetchedCodes.length, "codes");
      } else {
        throw new Error(`HTTP ${resp.status}`);
      }
    } catch (err) {
      console.warn("[DF-Auto] Sync failed (falling back to local cache):", err);
      updateSyncBanner("Server hlpdata.com offline. Đang dùng " + allCodes.length + " code nội bộ.", "offline");
      return allCodes.length;
    }

    if (fetchedCodes.length > 0) {
      const beforeCount = allCodes.length;
      allCodes = Array.from(new Set([...allCodes, ...fetchedCodes]));
      const newAdded = allCodes.length - beforeCount;

      chrome.storage.local.set({
        [STORAGE_KEYS.CODES]: allCodes,
        [STORAGE_KEYS.LAST_SYNC]: new Date().toLocaleString()
      });

      if (newAdded > 0) {
        updateSyncBanner(`Đã đồng bộ! Thêm +${newAdded} code mới từ hlpdata.com (Tổng: ${allCodes.length})`, "success");
      } else {
        updateSyncBanner(`Đã cập nhật mới nhất từ hlpdata.com (Tổng: ${allCodes.length} code)`, "success");
      }
    }

    updateUIStats();
    return allCodes.length;
  }

  function saveRedeemedCode(code) {
    redeemedSet.add(code);
    chrome.storage.local.set({
      [STORAGE_KEYS.REDEEMED]: Array.from(redeemedSet)
    });
  }

  // -------------------------------------------------------------
  // 2. DOM Helpers for Garena Redeem Page
  // -------------------------------------------------------------
  function getAccountInfo() {
    const isStateAfter = document.querySelector(".state.state-after.show");
    const bodyText = document.body ? document.body.innerText : "";
    const logoutBtn = Array.from(document.querySelectorAll("a, span, p")).find((el) =>
      (el.innerText || "").includes("Đăng xuất")
    );

    if (logoutBtn || isStateAfter) {
      // Try to find user name near logout
      let userName = "Đã đăng nhập";
      if (bodyText.includes("Cà Ri")) userName = "Cà Ri";
      else if (logoutBtn && logoutBtn.parentElement) {
        const parentTxt = logoutBtn.parentElement.innerText.replace("Đăng xuất", "").trim();
        if (parentTxt) userName = parentTxt;
      }
      return { isLoggedIn: true, name: userName };
    }
    return { isLoggedIn: false, name: "Chưa đăng nhập" };
  }

  function closeDialogs() {
    const dia = document.querySelector("#diaTips");
    if (dia) {
      const closeBtn = dia.querySelector(".btn-close");
      if (closeBtn) closeBtn.click();
      dia.style.display = "none";
    }
    const superTips = document.querySelector("#superTips");
    if (superTips) superTips.remove();
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // -------------------------------------------------------------
  // 3. Auto Redeem Execution Engine
  // -------------------------------------------------------------
  async function startRedeemProcess(onlyUnredeemed = true) {
    if (isRunning) return;

    const acc = getAccountInfo();
    if (!acc.isLoggedIn) {
      alert("Vui lòng đăng nhập tài khoản Garena trên trang trước khi đổi quà!");
      const signinBtn = document.querySelector(".btn-signin") || document.querySelector("#btn-login");
      if (signinBtn) signinBtn.click();
      return;
    }

    // Determine target codes
    let targetList = [...allCodes];
    if (onlyUnredeemed) {
      targetList = targetList.filter((c) => !redeemedSet.has(c));
    }

    if (targetList.length === 0) {
      alert("Tất cả các mã hiện tại đều đã được bạn đổi thành công trước đó!");
      return;
    }

    isRunning = true;
    isPaused = false;
    stopRequested = false;
    totalToRun = targetList.length;
    currentIdx = 0;
    successCount = 0;
    skipCount = 0;
    runResults = [];

    updateUIForRunning(true);
    addLogItem("HỆ THỐNG", `Bắt đầu xử lý ${totalToRun} mã...`, "info");

    for (let i = 0; i < targetList.length; i++) {
      if (stopRequested) {
        addLogItem("DỪNG", "Người dùng đã chủ động dừng tiến trình.", "error");
        break;
      }

      while (isPaused && !stopRequested) {
        await sleep(300);
      }
      if (stopRequested) break;

      const code = targetList[i];
      currentIdx = i + 1;
      updateProgressUI(currentIdx, totalToRun, code);

      // 1. Clean previous popups
      closeDialogs();

      // 2. Fill Code
      const input = document.querySelector("input.exc-input");
      const btn = document.querySelector(".btn-exchange");
      if (!input || !btn) {
        addLogItem(code, "Lỗi không tìm thấy ô nhập trên trang", "error");
        break;
      }

      input.value = code;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      await sleep(70);

      // 3. Click Exchange
      btn.click();

      // 4. Polling for server response up to 3.5s
      let resolved = false;
      const startTime = Date.now();

      while (Date.now() - startTime < 3500) {
        await sleep(120);

        // Check diaTips (Success modal)
        const dia = document.querySelector("#diaTips");
        if (dia && dia.style.display !== "none" && dia.style.visibility !== "hidden") {
          const msg = (dia.querySelector("p")?.innerText || "").trim();
          closeDialogs();

          const isSuccess = msg.toLowerCase().includes("thành công");
          if (isSuccess) {
            successCount++;
            saveRedeemedCode(code);
            addLogItem(code, "✅ Đã nhận thành công vào hộp thư!", "success");
            runResults.push({ code, status: "SUCCESS", msg });
          } else {
            skipCount++;
            addLogItem(code, `Bỏ qua: ${msg}`, "skip");
            runResults.push({ code, status: "SKIP", msg });
          }
          resolved = true;
          break;
        }

        // Check superTips (Invalid/Expired tooltip)
        const superTips = document.querySelector("#superTips");
        if (superTips && (superTips.innerText || "").trim()) {
          const msg = superTips.innerText.trim();
          superTips.remove();
          skipCount++;
          addLogItem(code, `Bỏ qua: ${msg}`, "skip");
          runResults.push({ code, status: "SKIP", msg });
          resolved = true;
          break;
        }
      }

      if (!resolved) {
        skipCount++;
        addLogItem(code, "Bỏ qua: Hết thời gian chờ phản hồi (Hết hạn)", "skip");
        runResults.push({ code, status: "TIMEOUT", msg: "Timeout" });
      }

      updateUIStats();

      // Debounce delay (Garena site has a 1.0s button lock)
      await sleep(1150);
    }

    isRunning = false;
    updateUIForRunning(false);
    addLogItem("HOÀN TẤT", `Đã xử lý xong: ${successCount} thành công, ${skipCount} bỏ qua.`, "success");
  }

  // -------------------------------------------------------------
  // 4. Floating UI Widget
  // -------------------------------------------------------------
  function buildWidget() {
    if (document.getElementById("df-auto-widget")) return;

    const widget = document.createElement("div");
    widget.id = "df-auto-widget";
    widget.innerHTML = `
      <div class="df-widget-header" id="df-widget-drag">
        <div class="df-header-left">
          <span class="df-logo-badge">DELTA FORCE</span>
          <span class="df-title">Auto Redeem HLP</span>
        </div>
        <div class="df-header-actions">
          <button class="df-btn-icon" id="df-btn-minimize" title="Thu nhỏ/Mở rộng">━</button>
          <button class="df-btn-icon" id="df-btn-close" title="Ẩn widget">✕</button>
        </div>
      </div>

      <div class="df-widget-body">
        <div class="df-status-row">
          <div class="df-status-card">
            <span class="df-card-label">Tài khoản</span>
            <span class="df-card-value highlight" id="df-acc-name">Đang kiểm tra...</span>
          </div>
          <div class="df-status-card">
            <span class="df-card-label">Tổng số Code</span>
            <span class="df-card-value" id="df-total-codes">0</span>
          </div>
          <div class="df-status-card">
            <span class="df-card-label">Đã ăn quà</span>
            <span class="df-card-value success" id="df-success-codes">0</span>
          </div>
        </div>

        <div class="df-sync-banner" id="df-sync-banner">
          <span>Server: <b>hlpdata.com</b></span>
          <span class="df-sync-link" id="df-btn-sync">Đồng bộ ngay ↻</span>
        </div>

        <div class="df-options-row">
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;">
            <input type="checkbox" id="df-chk-unredeemed" checked />
            <span>Chỉ đổi mã chưa từng nhận</span>
          </label>
          <span style="font-size:11px;color:#64748b;" id="df-pending-count">Sẵn sàng: 0</span>
        </div>

        <div class="df-progress-section" id="df-progress-section" style="display:none;">
          <div class="df-progress-header">
            <span id="df-prog-code">Đang xử lý: -</span>
            <span id="df-prog-text">0/0 (0%)</span>
          </div>
          <div class="df-progress-bar-bg">
            <div class="df-progress-bar-fill" id="df-prog-fill"></div>
          </div>
        </div>

        <button class="df-btn-primary" id="df-btn-main">
          ⚡ KÍCH HOẠT ĐỔI QUÀ TỰ ĐỘNG
        </button>

        <div class="df-btn-group" id="df-control-group" style="display:none;">
          <button class="df-btn-secondary" id="df-btn-pause">⏸ Tạm dừng</button>
          <button class="df-btn-secondary danger" id="df-btn-stop">⏹ Dừng</button>
        </div>

        <div class="df-log-container">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span class="df-log-title">Nhật ký tiến trình</span>
            <span class="df-sync-link" id="df-btn-copy-success" style="font-size:10.5px;">Sao chép mã quà</span>
          </div>
          <div class="df-log-list" id="df-log-list">
            <div class="df-log-item info">
              <span class="df-log-code">CHÀO MỪNG</span>
              <span class="df-log-status">Sẵn sàng tự động đổi</span>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(widget);

    // Bind widget interactions
    setupDrag(widget);
    setupEvents();
    updateUIStats();
  }

  function setupDrag(widget) {
    const header = widget.querySelector("#df-widget-drag");
    let isDragging = false;
    let startX, startY, initX, initY;

    header.addEventListener("mousedown", (e) => {
      if (e.target.closest(".df-header-actions")) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = widget.getBoundingClientRect();
      initX = rect.left;
      initY = rect.top;
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      widget.style.left = `${Math.max(10, initX + dx)}px`;
      widget.style.top = `${Math.max(10, initY + dy)}px`;
      widget.style.right = "auto";
    });

    document.addEventListener("mouseup", () => {
      isDragging = false;
    });
  }

  function setupEvents() {
    const minBtn = document.getElementById("df-btn-minimize");
    const closeBtn = document.getElementById("df-btn-close");
    const syncBtn = document.getElementById("df-btn-sync");
    const mainBtn = document.getElementById("df-btn-main");
    const pauseBtn = document.getElementById("df-btn-pause");
    const stopBtn = document.getElementById("df-btn-stop");
    const copyBtn = document.getElementById("df-btn-copy-success");
    const chkUnredeemed = document.getElementById("df-chk-unredeemed");
    const widget = document.getElementById("df-auto-widget");

    minBtn.addEventListener("click", () => {
      widget.classList.toggle("df-minimized");
      minBtn.innerText = widget.classList.contains("df-minimized") ? "➕" : "━";
    });

    closeBtn.addEventListener("click", () => {
      widget.style.display = "none";
    });

    syncBtn.addEventListener("click", () => {
      syncWithServer();
    });

    chkUnredeemed.addEventListener("change", () => {
      updateUIStats();
    });

    mainBtn.addEventListener("click", () => {
      const onlyUnredeemed = chkUnredeemed.checked;
      startRedeemProcess(onlyUnredeemed);
    });

    pauseBtn.addEventListener("click", () => {
      isPaused = !isPaused;
      pauseBtn.innerText = isPaused ? "▶ Tiếp tục" : "⏸ Tạm dừng";
      addLogItem("HỆ THỐNG", isPaused ? "Đã tạm dừng" : "Tiếp tục chạy", "info");
    });

    stopBtn.addEventListener("click", () => {
      stopRequested = true;
    });

    copyBtn.addEventListener("click", () => {
      const redeemedArr = Array.from(redeemedSet);
      if (redeemedArr.length === 0) {
        alert("Chưa có mã nào được đổi thành công.");
        return;
      }
      navigator.clipboard.writeText(redeemedArr.join("\n")).then(() => {
        alert(`Đã sao chép ${redeemedArr.length} mã đã nhận quà vào Clipboard!`);
      });
    });
  }

  function updateSyncBanner(text, type) {
    const banner = document.getElementById("df-sync-banner");
    if (!banner) return;
    banner.className = `df-sync-banner ${type || ""}`;
    banner.innerHTML = `<span>${text}</span> <span class="df-sync-link" id="df-btn-sync-inline">↻</span>`;
    document.getElementById("df-btn-sync-inline")?.addEventListener("click", () => syncWithServer());
  }

  function updateUIStats() {
    const acc = getAccountInfo();
    const accEl = document.getElementById("df-acc-name");
    const totalEl = document.getElementById("df-total-codes");
    const successEl = document.getElementById("df-success-codes");
    const pendingEl = document.getElementById("df-pending-count");
    const mainBtn = document.getElementById("df-btn-main");
    const chkUnredeemed = document.getElementById("df-chk-unredeemed");

    if (accEl) accEl.innerText = acc.name;
    if (totalEl) totalEl.innerText = allCodes.length;
    if (successEl) successEl.innerText = redeemedSet.size;

    const pending = chkUnredeemed && chkUnredeemed.checked
      ? allCodes.filter((c) => !redeemedSet.has(c)).length
      : allCodes.length;

    if (pendingEl) pendingEl.innerText = `Sẵn sàng: ${pending}`;

    if (mainBtn && !isRunning) {
      if (!acc.isLoggedIn) {
        mainBtn.innerText = "🔑 ĐĂNG NHẬP GARENA ĐỂ ĐỔI";
        mainBtn.style.background = "linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)";
      } else {
        mainBtn.innerText = `⚡ ĐỔI ${pending} MÃ TỰ ĐỘNG`;
        mainBtn.style.background = "linear-gradient(135deg, #ff7a00 0%, #ff5500 100%)";
      }
    }
  }

  function updateUIForRunning(running) {
    const mainBtn = document.getElementById("df-btn-main");
    const ctrlGroup = document.getElementById("df-control-group");
    const progSec = document.getElementById("df-progress-section");

    if (running) {
      if (mainBtn) mainBtn.style.display = "none";
      if (ctrlGroup) ctrlGroup.style.display = "flex";
      if (progSec) progSec.style.display = "flex";
    } else {
      if (mainBtn) mainBtn.style.display = "block";
      if (ctrlGroup) ctrlGroup.style.display = "none";
      updateUIStats();
    }
  }

  function updateProgressUI(current, total, currentCode) {
    const fill = document.getElementById("df-prog-fill");
    const text = document.getElementById("df-prog-text");
    const codeEl = document.getElementById("df-prog-code");

    const pct = Math.round((current / total) * 100);
    if (fill) fill.style.width = `${pct}%`;
    if (text) text.innerText = `${current}/${total} (${pct}%)`;
    if (codeEl) codeEl.innerText = `Đang xử lý: ${currentCode}`;
  }

  function addLogItem(code, statusText, type) {
    const list = document.getElementById("df-log-list");
    if (!list) return;

    const item = document.createElement("div");
    item.className = `df-log-item ${type || ""}`;
    item.innerHTML = `
      <span class="df-log-code">${code}</span>
      <span class="df-log-status">${statusText}</span>
    `;
    list.appendChild(item);
    list.scrollTop = list.scrollHeight;
  }

  // -------------------------------------------------------------
  // 5. Main Initialization
  // -------------------------------------------------------------
  async function init() {
    await loadInitialData();
    buildWidget();

    // Auto-sync in background on load
    setTimeout(() => {
      syncWithServer();
    }, 1200);

    // Periodically re-check login status
    setInterval(() => {
      if (!isRunning) updateUIStats();
    }, 3000);
  }

  // Run on page ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
