// Popup Logic for Delta Force Auto Redeem
const DEFAULT_SERVER_URL = "https://hlpdata.com/api/df-codes.json";
const STORAGE_KEYS = {
  CODES: "df_codes_list",
  REDEEMED: "df_redeemed_history",
  SERVER_URL: "df_server_url",
  LAST_SYNC: "df_last_sync_time"
};

document.addEventListener("DOMContentLoaded", async () => {
  const statTotal = document.getElementById("stat-total");
  const statRedeemed = document.getElementById("stat-redeemed");
  const syncStatus = document.getElementById("sync-status");
  const inputServerUrl = document.getElementById("input-server-url");
  const btnOpenRedeem = document.getElementById("btn-open-redeem");
  const btnSyncNow = document.getElementById("btn-sync-now");
  const btnSaveUrl = document.getElementById("btn-save-url");
  const btnClearHistory = document.getElementById("btn-clear-history");

  async function loadData() {
    chrome.storage.local.get(
      [STORAGE_KEYS.CODES, STORAGE_KEYS.REDEEMED, STORAGE_KEYS.SERVER_URL, STORAGE_KEYS.LAST_SYNC],
      async (data) => {
        let codes = data[STORAGE_KEYS.CODES] || [];
        if (codes.length === 0) {
          try {
            const res = await fetch(chrome.runtime.getURL("data/default_codes.json"));
            const json = await res.json();
            codes = json.codes || [];
            chrome.storage.local.set({ [STORAGE_KEYS.CODES]: codes });
          } catch (e) {
            console.error(e);
          }
        }

        const redeemed = data[STORAGE_KEYS.REDEEMED] || [];
        const serverUrl = data[STORAGE_KEYS.SERVER_URL] || DEFAULT_SERVER_URL;
        const lastSync = data[STORAGE_KEYS.LAST_SYNC] || "Chưa đồng bộ";

        statTotal.innerText = codes.length;
        statRedeemed.innerText = redeemed.length;
        inputServerUrl.value = serverUrl;
        syncStatus.innerHTML = `Lần đồng bộ cuối: <b>${lastSync}</b>`;
      }
    );
  }

  loadData();

  // Open Redeem Page
  btnOpenRedeem.addEventListener("click", () => {
    chrome.tabs.query({ url: "*://redeem.df.garena.sg/*" }, (tabs) => {
      if (tabs.length > 0) {
        chrome.tabs.update(tabs[0].id, { active: true });
      } else {
        chrome.tabs.create({ url: "https://redeem.df.garena.sg/vi/cdkgarena.html" });
      }
      window.close();
    });
  });

  // Save Server URL
  btnSaveUrl.addEventListener("click", () => {
    const newUrl = inputServerUrl.value.trim();
    if (!newUrl) return;
    chrome.storage.local.set({ [STORAGE_KEYS.SERVER_URL]: newUrl }, () => {
      alert("Đã lưu địa chỉ Server API!");
    });
  });

  // Sync Codes Now
  btnSyncNow.addEventListener("click", async () => {
    const url = inputServerUrl.value.trim() || DEFAULT_SERVER_URL;
    syncStatus.innerHTML = `Đang tải mã mới từ <b>${url}</b>...`;
    btnSyncNow.disabled = true;

    try {
      const resp = await fetch(url, { cache: "no-cache", mode: "cors" });
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      const json = await resp.json();
      const newCodes = Array.isArray(json) ? json : (json.codes || []);

      chrome.storage.local.get([STORAGE_KEYS.CODES], (data) => {
        const existing = data[STORAGE_KEYS.CODES] || [];
        const merged = Array.from(new Set([...existing, ...newCodes]));
        const added = merged.length - existing.length;

        const now = new Date().toLocaleString();
        chrome.storage.local.set({
          [STORAGE_KEYS.CODES]: merged,
          [STORAGE_KEYS.LAST_SYNC]: now
        }, () => {
          btnSyncNow.disabled = false;
          statTotal.innerText = merged.length;
          syncStatus.innerHTML = `Thành công! +${added} mã mới (${now})`;
        });
      });
    } catch (e) {
      btnSyncNow.disabled = false;
      syncStatus.innerHTML = `<span style="color:#f87171;">Lỗi đồng bộ: ${e.message}</span>`;
    }
  });

  // Clear History
  btnClearHistory.addEventListener("click", (e) => {
    e.preventDefault();
    if (confirm("Bạn có chắc chắn muốn xóa lịch sử các mã đã đổi thành công để đổi lại từ đầu?")) {
      chrome.storage.local.set({ [STORAGE_KEYS.REDEEMED]: [] }, () => {
        statRedeemed.innerText = "0";
        alert("Đã xóa lịch sử đổi quà!");
      });
    }
  });
});
