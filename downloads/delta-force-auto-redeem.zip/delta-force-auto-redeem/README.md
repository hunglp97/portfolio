# 🎯 Delta Force Auto Redeem - Chrome Extension (by HLP Data)

Extension tự động nhập và đổi toàn bộ mã CDKey cho game **Delta Force (Garena)** trên trang `https://redeem.df.garena.sg/`.

---

## 🌟 Tính Năng Nổi Bật

1. **Có sẵn 395+ Mã Code Full**:
   - Tích hợp sẵn toàn bộ 395+ mã quà tặng trong gói cài đặt (hoạt động offline ngay cả khi server chưa online).
2. **Tự Động Đồng Bộ Mã Mới từ Server `hlpdata.com`**:
   - Khi mở trang hoặc bấm **Đồng bộ ngay**, extension tự động kết nối `https://hlpdata.com/api/df-codes.json` để tải về các mã quà mới nhất.
3. **Floating Tactical Dashboard Trên Web**:
   - Giao diện nổi thông minh, có thể kéo thả bất kỳ vị trí nào, thu nhỏ/phóng to tùy thích.
   - Nhận diện trạng thái đăng nhập tài khoản (ví dụ "Cà Ri").
4. **Cơ Chế Auto Redeem Thông Minh**:
   - Tự động bỏ qua (Skip) mã không hợp lệ hoặc hết hạn mà không làm nghẽn tiến trình.
   - Bắt chính xác popup nhận thưởng thành công, tự động đóng modal.
   - Tự động debounce tránh bị rate-limit hoặc khóa nút của Garena.
   - Tùy chọn **"Chỉ đổi mã chưa từng nhận"** giúp tiết kiệm thời gian, không bao giờ phải thử lại những mã đã ăn quà thành công.
5. **Quản Lý & Xuất Lịch Sử**:
   - Lưu trữ danh sách mã đã nhận thành công vào bộ nhớ trình duyệt (`chrome.storage.local`).
   - Nút **Sao chép mã quà** một chạm để xuất danh sách đã nhận thành công.

---

## 📦 Hướng Dẫn Cài Đặt Vào Google Chrome

1. Mở trình duyệt Google Chrome, truy cập vào đường dẫn:
   ```
   chrome://extensions/
   ```
2. Bật công tắc **"Chế độ dành cho nhà phát triển" (Developer mode)** ở góc trên bên phải.
3. Bấm vào nút **"Tải tiện ích đã giải nén" (Load unpacked)** ở góc trên bên trái.
4. Chọn thư mục:
   ```
   /Users/ezesoft-mac-3/Developer/survey-pilot/extensions/delta-force-auto-redeem
   ```
   *(Hoặc thư mục chứa extension trên máy của người dùng khác).*
5. Tiện ích **Delta Force Auto Redeem - HLP Data** sẽ xuất hiện trên thanh công cụ!

---

## 🎮 Cách Sử Dụng

1. Mở trang đổi quà Delta Force của Garena:
   👉 `https://redeem.df.garena.sg/vi/cdkgarena.html`
2. Đăng nhập vào tài khoản Garena của bạn.
3. Floating Widget màu cam đen của Delta Force sẽ tự động hiển thị ở góc phải màn hình:
   - Hiển thị tên tài khoản.
   - Tự động kiểm tra và đồng bộ code mới từ `hlpdata.com`.
4. Bấm **⚡ KÍCH HOẠT ĐỔI QUÀ TỰ ĐỘNG**.
5. Thư giãn và theo dõi tiến trình! Quà sẽ được tự động chuyển thẳng vào **Hộp thư (Mailbox)** trong game.
